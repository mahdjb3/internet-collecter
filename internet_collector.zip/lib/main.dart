import 'package:flutter/material.dart';
import 'package:sqflite/sqflite.dart';
import 'database.dart';
import 'model.dart';
import 'notifications.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final db = await DB.initDB();
  await Notify.init();
  runApp(MyApp(db: db));
}

class MyApp extends StatelessWidget {
  final Database db;
  const MyApp({required this.db});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Home(db: db),
    );
  }
}

class Home extends StatefulWidget {
  final Database db;
  const Home({required this.db});

  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  List<Subscriber> subs = [];
  final nameC = TextEditingController();
  final phoneC = TextEditingController();
  final priceC = TextEditingController();

  loadData() async {
    final data = await widget.db.query("subs");
    subs = data.map((e) {
      return Subscriber(
        id: e['id'] as int,
        name: e['name'] as String,
        phone: e['phone'] as String,
        price: e['price'] as int,
        lastPay: e['lastPay'] as int,
      );
    }).toList();
    setState(() {});
  }

  addSub() async {
    await widget.db.insert("subs", {
      "name": nameC.text,
      "phone": phoneC.text,
      "price": int.tryParse(priceC.text) ?? 0,
      "lastPay": DateTime.now().millisecondsSinceEpoch
    });
    nameC.clear();
    phoneC.clear();
    priceC.clear();
    loadData();
  }

  markPaid(Subscriber s) async {
    await widget.db.update(
      "subs",
      {"lastPay": DateTime.now().millisecondsSinceEpoch},
      where: "id = ?",
      whereArgs: [s.id],
    );
    loadData();
  }

  checkDelay(Subscriber s) {
    final diff = DateTime.now()
        .difference(DateTime.fromMillisecondsSinceEpoch(s.lastPay))
        .inDays;

    return diff > 30;
  }

  @override
  void initState() {
    super.initState();
    loadData();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("إدارة المشتركين")),
      body: Column(
        children: [
          TextField(controller: nameC, decoration: InputDecoration(labelText: "اسم المشترك")),
          TextField(controller: phoneC, decoration: InputDecoration(labelText: "رقم الهاتف")),
          TextField(controller: priceC, decoration: InputDecoration(labelText: "السعر الشهري")),
          ElevatedButton(onPressed: addSub, child: Text("إضافة مشترك")),
          Expanded(
            child: ListView.builder(
              itemCount: subs.length,
              itemBuilder: (_, i) {
                final s = subs[i];
                final delayed = checkDelay(s);
                if (delayed) {
                  Notify.showDelayAlert(s.name);
                }

                return ListTile(
                  title: Text(s.name),
                  subtitle: Text("رقم: ${s.phone} — سعر: ${s.price}"),
                  trailing: Text(
                    delayed ? "متأخر" : "منتظم",
                    style: TextStyle(
                      color: delayed ? Colors.red : Colors.green,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  onTap: () => markPaid(s),
                );
              },
            ),
          )
        ],
      ),
    );
  }
}