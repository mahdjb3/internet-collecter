import 'package:flutter_local_notifications/flutter_local_notifications.dart';

class Notify {
  static final plugin = FlutterLocalNotificationsPlugin();

  static Future init() async {
    const android = AndroidInitializationSettings('@mipmap/ic_launcher');
    const settings = InitializationSettings(android: android);
    await plugin.initialize(settings);
  }

  static Future showDelayAlert(String name) async {
    const android = AndroidNotificationDetails(
      "delay",
      "Late Payments",
      importance: Importance.high,
      priority: Priority.high,
    );

    await plugin.show(
      0,
      "مشترك متأخر",
      "$name لم يدفع منذ 30 يوم",
      NotificationDetails(android: android),
    );
  }
}