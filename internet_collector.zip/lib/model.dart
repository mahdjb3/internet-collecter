class Subscriber {
  final int? id;
  final String name;
  final String phone;
  final int price;       
  final int lastPay;     

  Subscriber({
    this.id,
    required this.name,
    required this.phone,
    required this.price,
    required this.lastPay,
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'name': name,
      'phone': phone,
      'price': price,
      'lastPay': lastPay,
    };
  }
}