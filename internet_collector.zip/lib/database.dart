import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';

class DB {
  static Future<Database> initDB() async {
    final path = join(await getDatabasesPath(), 'subs.db');
    return openDatabase(
      path,
      onCreate: (db, version) async {
        await db.execute('''
        CREATE TABLE subs (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          name TEXT,
          phone TEXT,
          price INTEGER,
          lastPay INTEGER
        )
        ''');
      },
      version: 1,
    );
  }
}